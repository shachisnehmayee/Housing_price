The projects helps to predict the Sale Price of houses based on several predictor variables. 

There are large number of columns which we have been used for the prediction. 
Several methods like data cleaning, EDA, data mapping and dummy variable creation is used for preparing data for analysis.

In addition to this, I have created two extra variables as AgeofBuilding and AgeofGarage which would help us to 
get a clear picture for establishing a relation between YearRemodelling ,Garage Built year fields and Saleprice of the building.

We have first used RFE model to find the best 60 predictor variables.
We then implemented Linear Regression, Ridge regression and Lasso regression. We also learnt how Ridge and Lasso regression helps to regularize our model based on the optimal value of alpha. 

However, Ridge regression does not make coefficients zero and prefer to keep all the predictor variables, Lasso regression removes few predictor variables by setting their coefficients zero.
 
